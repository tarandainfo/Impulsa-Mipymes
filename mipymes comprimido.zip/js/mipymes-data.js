// ==========================================
// DATOS DE MIPYMES
// ==========================================
//
// ⚠️ ESTE ES EL ÚNICO ARCHIVO QUE EL ADMINISTRADOR
// EDITA PARA CARGAR UNA MIPYME NUEVA.
//
// El usuario de la web NUNCA puede agregar, editar
// ni borrar mipymes: no hay ningún formulario público
// para eso. Los visitantes solo pueden hacer clic en
// una mipyme (abre su ficha) o en los botones de
// WhatsApp / Instagram.
//
// Para agregar una mipyme nueva:
//   1) Copiá uno de los bloques { ... } de abajo.
//   2) Pegalo antes del corchete final "]".
//   3) Completá los datos de la mipyme nueva.
//   4) Guardá, subí los cambios al repositorio
//      (git add / commit / push) y publicá de nuevo.
//
// Tip: también podés usar admin/generador-mipyme.html
// para armar el bloque completando un formulario.
//
// CAMPOS:
//   - productoImagen: la foto que se ve en la tarjeta
//     de la lista principal (index.html).
//   - fotosCarrusel: entre 1 y 5 fotos para el carrusel
//     de la ficha de la mipyme (su propia página).
//   - descripcionLarga: 2 párrafos para la ficha
//     (si no se completa, se usa "descripcion").
//   - notaPeriodistica: link a la nota/artículo sobre
//     la mipyme. Si no tiene, dejalo como "" y ese link
//     no se muestra en la ficha.
//   - verificada: la palomita azul de "mipyme verificada".
//     Las mipymes de esta lista son las que pagaron por estar
//     destacadas, así que TODAS la llevan (verificada: true;
//     si te olvidás de la línea, también la llevan). Solo si
//     alguna no debe llevarla, poné verificada: false. La
//     palomita aparece sola junto al nombre en la portada,
//     las tarjetas, la ficha y la guía de mipymes.
//   - productoImagenMovil (opcional): otra foto para la
//     tarjeta de la lista en celular (pantallas de hasta
//     600 px). Sirve cuando la foto principal es muy vertical
//     o lleva texto, como un logo. Si no se pone, se usa
//     productoImagen en todos los tamaños.
//   - rubroGuia (opcional): el rubro con el que entra a la guía
//     de mipymes. Si no se pone, se usa la categoría
//     (ver DIRECTORIO_EQUIVALENCIAS_RUBRO en directorio-data.js).
// ==========================================

const MIPYMES_DATA = [

    {
        nombre: "Báez Maldonado y Bolla Consulting",
        categoria: "Consultoría",
        verificada: true,

        descripcion:
            "Consultora familiar especializada en proyectos de maquila, estructuración de sociedades e inversiones, asesoría legal, servicios notariales y gestión migratoria para empresas e inversionistas nacionales y extranjeros.",

        descripcionLarga: [
            "Báez Maldonado y Bolla Consulting es una consultora familiar paraguaya fundada por el Dr. Alcides Emilio Báez Maldonado, reconocido por su aporte a la creación e impulso de la Ley de Maquila en Paraguay, junto con la escribana pública María Jackeline Bolla de Báez. La firma nació con el objetivo de acompañar a empresas y emprendedores en la estructuración de proyectos de maquila, constitución de sociedades y desarrollo de inversiones, combinando conocimientos jurídicos, notariales y de comercio internacional.",
            "Actualmente, la consultora continúa el legado familiar bajo la dirección de la Abg. Adria Báez Bolla, la Lic. Eugenia Báez Bolla, y la Escribana María Jackeline Bolla de Báez. Ofrece servicios integrales que incluyen estructuración, asesoramiento e implementación de Proyectos de Maquila y otras leyes de incentivo a la inversión como la ex 60/90, aperturas societarias con mantenimiento con una escribanía propia de más de 25 años en el mercado, mantenimiento de sociedades con soporte contable, representación legal, trámites migratorios y acompañamiento para el desembarco de extranjeros en Paraguay. Su propuesta se distingue por la atención personalizada, el trato humano y el acompañamiento continuo durante las distintas etapas de cada proyecto."
        ],

        ubicacion: "Asunción, Paraguay",

        whatsapp: "595981811445",

        instagram: "https://www.instagram.com/bmbconsulting/",

        productoImagen:
            "./assets/img/bolla-consultora/foto-tarjeta-vertical.jpg",

        productoImagenMovil:
            "./assets/img/bolla-consultora/foto-tarjeta.jpg",

        perfilImagen:
            "./assets/img/bolla-consultora/foto-perfil.png",

        fotosCarrusel: [
            "./assets/img/bolla-consultora/foto-principal.png",
            "./assets/img/bolla-consultora/foto-2.jpeg",
            "./assets/img/bolla-consultora/foto-3.jpg",
            "./assets/img/bolla-consultora/foto-4.jpg"
        ],

        promocion:
            "Consultá por los servicios disponibles.",

        notaPeriodistica: ""

    },

    {
        nombre: "Fabricante Muebles",
        categoria: "Artesanía",
        verificada: true,

        descripcion:
            "Empresa paraguaya dedicada a la fabricación y comercialización de muebles para hogares, oficinas y espacios comerciales, con más de 300 opciones en stock y diseños a medida.",

        descripcionLarga: [
            "Fabricante Muebles, liderada por Rodrigo Sosa y Yeni Cabral, es una empresa paraguaya con más de 23 años de trayectoria en el sector del mobiliario. Se especializa en la fabricación y comercialización de muebles para el hogar, oficinas y comercios, con una amplia variedad de productos que incluye juegos de comedor, sofás, camas, placares, escritorios y soluciones de almacenamiento. Además, ofrece fabricación a medida, asesoramiento personalizado y toma de medidas sin costo para proyectos especiales.",
            "A lo largo de su trayectoria, la empresa ha logrado consolidarse tanto en el mercado minorista como en el corporativo, trabajando con empresas como Tupi Electrodomésticos, Electrojet, Big Center y Wilmar Center. Con fabricación propia, precios competitivos y atención personalizada, Fabricante Muebles busca continuar creciendo, innovando y ofreciendo soluciones funcionales y accesibles para más hogares y empresas paraguayas."
        ],

        ubicacion: "Asunción, Paraguay",

        whatsapp: "595983780446",

        instagram: "https://www.instagram.com/fabricante_muebles/",

        productoImagen:
            "./assets/img/fabricante-muebles/foto-principal.jpg",

        perfilImagen:
            "./assets/img/fabricante-muebles/perfil.jpeg",

        fotosCarrusel: [
            "./assets/img/fabricante-muebles/foto-1.jpg",
            "./assets/img/fabricante-muebles/foto-2.jpg",
            "./assets/img/fabricante-muebles/foto-3.jpg",
            "./assets/img/fabricante-muebles/foto-4.jpg",
            "./assets/img/fabricante-muebles/foto-5.jpg"
        ],

        promocion:
            "Consultá por los servicios disponibles.",

        notaPeriodistica: ""

    },

    {
        nombre: "Eventos Paraguay",
        categoria: "Servicios para eventos",
        verificada: true,

        descripcion:
            "Empresa especializada en producción técnica y equipamiento integral para eventos, con servicios de pantallas LED, sonido, iluminación profesional, streaming, montaje de escenarios, mobiliario y traducción simultánea.",

        descripcionLarga: [
            "Eventos Paraguay, fundada por Leonora Delvalle, es una empresa paraguaya dedicada a la producción técnica y al equipamiento integral para eventos corporativos, congresos, ferias, exposiciones, espectáculos y acontecimientos sociales. Su propuesta consiste en brindar soluciones adaptadas a las necesidades de cada proyecto, ofreciendo tecnología y equipamiento para garantizar el desarrollo de eventos profesionales.",
            "A lo largo de su trayectoria, la empresa ha invertido en tecnología, pantallas LED, equipos de sonido, iluminación profesional y mobiliario para ampliar su capacidad operativa y mejorar la calidad de sus servicios. Con la mirada puesta en el futuro, busca consolidarse como referente en el sector de eventos en Paraguay, incorporando nuevas tecnologías, ampliando su oferta y fortaleciendo sus vínculos con empresas e instituciones."
        ],

        ubicacion: "Asunción, Paraguay",

        whatsapp: "595992489504",

        instagram: "https://www.instagram.com/eventosparaguay_/",

        productoImagen:
            "./assets/img/eventos-paraguay/principal.jpeg",

        perfilImagen:
            "./assets/img/eventos-paraguay/foto-perfil.jpeg",

        fotosCarrusel: [
            "./assets/img/eventos-paraguay/foto-1.jpg",
            "./assets/img/eventos-paraguay/foto-2.jpg",
            "./assets/img/eventos-paraguay/foto-3.jpg",
            "./assets/img/eventos-paraguay/foto-4.jpg",
            "./assets/img/eventos-paraguay/foto-5.jpg"
        ],

        promocion:
            "Consultá por los servicios disponibles.",

        notaPeriodistica: ""

    },
    
    {
        nombre: "Fátima Sosa Organización y ambientación de eventos",
        categoria: "Organización de eventos",
        verificada: true,

        descripcion:
            "Servicio especializado en la organización, planificación y ambientación de eventos, creando propuestas personalizadas y cuidando cada detalle de la celebración.",

        descripcionLarga: [
            "Fátima Sosa – Organización y Ambientación de Eventos nació a partir de una experiencia personal: la organización de su propia boda. A partir de ese momento, Fátima Sosa decidió convertir su interés por la planificación y decoración de celebraciones en un emprendimiento dedicado a crear y coordinar eventos.",
            "Actualmente, ofrece servicios de organización, planificación y ambientación de eventos, trabajando en cada proyecto de manera personalizada. Para fortalecer su propuesta, ha invertido en nuevos materiales y capacitación, mientras que su objetivo es seguir creciendo y asumir la organización de eventos cada vez más complejos."
        ],

        ubicacion: "Asunción, Paraguay",

        whatsapp: "595984128509",

        instagram: "https://www.instagram.com/fatimasosaeventos?stkn=MWF1a2x5azE0eG5naQ%3D%3D&utm_source=qr",

        productoImagen:
            "./assets/img/fatima-sosa/foto-1.jpg",

        perfilImagen:
            "./assets/img/fatima-sosa/foto-perfil.jpg",

        fotosCarrusel: [
            "./assets/img/fatima-sosa/foto-1.jpg",
            "./assets/img/fatima-sosa/foto-2.jpg",
            "./assets/img/fatima-sosa/foto-3.jpg",
            "./assets/img/fatima-sosa/foto-4.jpg",
            "./assets/img/fatima-sosa/foto-5.jpg"
        ],

        promocion:
            "Consultá por los servicios disponibles.",

        notaPeriodistica: ""

    },

    {
        nombre: "AG Organización Contable",
        categoria: "Servicios contables empresariales",
        verificada: true,

        descripcion:
            "Firma especializada en servicios contables, tributarios, laborales y administrativos, con asesoramiento integral para emprendedores, empresas, MiPymes e inversionistas.",

        descripcionLarga: [
            "AG Organización Contable es una firma con más de 20 años de trayectoria, liderada por Fanny Godoy Britos, que brinda soluciones integrales en las áreas contable, tributaria, laboral y administrativa. Su propuesta acompaña a emprendedores y empresas desde la formalización y constitución de sus negocios hasta la gestión cotidiana y el cumplimiento de sus obligaciones.",
            "Además, ofrece servicios de auditoría externa, registro de marcas, asesoramiento para emprendedores y MiPymes, y asistencia a extranjeros interesados en establecerse e invertir en Paraguay. Su atención personalizada se basa en tres pilares: Confianza, Claridad y Compromiso, buscando brindar acompañamiento profesional durante las distintas etapas de cada proyecto."
        ],

        ubicacion: "Hernandarias, Paraguay",

        whatsapp: "595991844919",

        instagram: "https://www.instagram.com/agorganizacioncontable/",

        productoImagen:
            "./assets/img/ag-contable/ag-principal.jpeg",

        perfilImagen:
            "./assets/img/ag-contable/ag-perfil.jpeg",

        fotosCarrusel: [
            "./assets/img/ag-contable/ag-foto1.jpg",
            "./assets/img/ag-contable/ag-foto2.jpg",
            "./assets/img/ag-contable/ag-foto3.jpg"
        ],

        promocion:
            "Consultá por los servicios disponibles.",

        notaPeriodistica: ""

    },

    {
        nombre: "Hey",
        categoria: "Moda y diseño",
        verificada: true,

        descripcion:
            "Estudio creativo que desarrolla regalos y experiencias personalizadas para personas y empresas, diseñando cada propuesta según la ocasión, identidad y presupuesto del cliente.",

        descripcionLarga: [
            "Hey es un emprendimiento creado por las amigas Maira Jemima Cañete y Belén Sanabria, que decidieron unir creatividad y regalos personalizados. Con una inversión inicial cercana a G. 6 millones, comenzaron desarrollando propuestas a medida para particulares y empresas, sin trabajar con un catálogo predeterminado y buscando que cada obsequio tenga un significado especial.",
            "Uno de sus proyectos más recordados fue la personalización de 10 pares de championes Nike para Bancard, intervenidos a mano con el logotipo de la empresa y acompañados de un packaging especialmente diseñado. Actualmente, Hey trabaja de manera 100% online, recibe pedidos a través de redes sociales y realiza envíos y delivery, mientras proyecta contar con un taller propio para atender clientes de forma presencial."
        ],

        ubicacion: "Asunción, Paraguay",

        whatsapp: "595972390058",

        instagram: "https://www.instagram.com/hey.megusta?igsh=Nmh0bnJ4MnRkc29m",

        productoImagen:
            "./assets/img/hey/foto-principal-producto.jpeg",

        perfilImagen:
            "./assets/img/hey/foto-perfil.JPEG",

        fotosCarrusel: [
            "./assets/img/hey/foto-principal-producto.jpeg",
            "./assets/img/hey/foto-dos.jpeg",
            "./assets/img/hey/foto-tres.jpg",
            "./assets/img/hey/foto-cuatro.jpg",
            "./assets/img/hey/foto-cinco.jpg"
        ],

        promocion:
            "Consultá por los servicios disponibles.",

        notaPeriodistica: ""

    },

    {
        nombre: "Rubén Cardus Fotografía",
        categoria: "Servicios audiovisuales",
        verificada: true,

        descripcion:
            "Servicio audiovisual especializado en fotografía y video para eventos sociales, creación de contenido, manejo de redes sociales y fotografía gastronómica.",

        descripcionLarga: [
            "Ruben Angel Cardus Famoso comenzó su camino en el mundo audiovisual a los 18 años, trabajando como secretario de luces y adquiriendo experiencia desde adentro de la producción. Con el tiempo, esa primera aproximación se convirtió en una profesión y en su propio emprendimiento, enfocado principalmente en la fotografía y cobertura audiovisual de eventos sociales como bodas, cumpleaños, bautismos y otras celebraciones.",
            "Actualmente, además de la cobertura de eventos, ofrece servicios de manejo de redes sociales, creación de contenido y fotografía gastronómica para empresas y emprendimientos. Para mejorar la calidad de sus trabajos, fue incorporando equipos profesionales, tecnología y capacitación constante, con el objetivo de consolidar su emprendimiento, ampliar sus servicios y formar un equipo que le permita asumir proyectos de mayor envergadura."
        ],

        ubicacion: "Asunción, Paraguay",

        whatsapp: "595982451062",

        instagram: "https://www.instagram.com/rubencardusfotografo/",

        productoImagen:
            "./assets/img/ruben-cardus/foto-foto-principal.jpg",

        perfilImagen:
            "./assets/img/ruben-cardus/foto-perfil.jpeg",

        fotosCarrusel: [
            "./assets/img/ruben-cardus/foto-foto-principal.jpg",
            "./assets/img/ruben-cardus/foto-dos.jpg",
            "./assets/img/ruben-cardus/foto-tres.jpg",
            "./assets/img/ruben-cardus/foto-cuatro.jpg",
            "./assets/img/ruben-cardus/foto-cinco.jpg"
        ],

        promocion:
            "Consultá por los servicios disponibles.",

        notaPeriodistica: ""

    },

    {
        nombre: "Che Retã Resto Café",
        categoria: "Gastronomía",
        verificada: true,

        descripcion:
            "Resto café que combina platos tradicionales y propuestas innovadoras con una identidad inspirada en la cultura y las tradiciones paraguayas.",

        descripcionLarga: [
            "Che Retã Resto Café nace a partir de una reunión entre Santiago Benítez y César Castro, quienes decidieron unir sus conocimientos y apostar por el crecimiento dentro del rubro gastronómico. El emprendimiento ofrece una variedad de platos tradicionales y propuestas no convencionales, acompañados de una propuesta de café que busca diferenciarse.",
            "Con una identidad inspirada en el amor por Paraguay, su gente, su tierra y sus tradiciones, Che Retã busca que cada producto y cada detalle transmita parte de la cultura local. Sus impulsores tienen como objetivo seguir creciendo, desarrollar nuevas propuestas y demostrar que, a través de métodos innovadores, es posible construir un emprendimiento sólido apostando por lo nuestro."
        ],

        ubicacion: "Asunción, Paraguay",

        whatsapp: "595971304087",

        instagram: "https://www.instagram.com/cheretacafe_/",

        productoImagen:
            "./assets/img/che-reta-cafe/foto-1.jpg",

        perfilImagen:
            "./assets/img/che-reta-cafe/foto-perfil-che-reta.png",

        fotosCarrusel: [
            "./assets/img/che-reta-cafe/foto-1.jpg",
            "./assets/img/che-reta-cafe/foto-2.jpg",
            "./assets/img/che-reta-cafe/foto-3.jpg"
        ],

        promocion:
            "Consultá por los servicios disponibles.",

        notaPeriodistica: ""

    },

    {
        nombre: "El Fogón del Patio",
        categoria: "Decoración y productos para exteriores",
        verificada: true,

        descripcion:
            "Emprendimiento dedicado a la fabricación y comercialización de fogoneros, parrillas y productos para disfrutar y decorar espacios exteriores.",

        descripcionLarga: [
            "El Fogón del Patio, creado por Enrique Román Helbing durante la pandemia, nació a partir de una fogata improvisada en el patio de su casa. Tras fabricar un fogonero para uso personal y compartirlo en redes sociales, comenzó a recibir pedidos y decidió convertir la idea en un negocio.",
            "Con el tiempo, amplió su propuesta a fogoneros, parrillas, mesas rústicas, espejos decorativos y accesorios para espacios exteriores. Actualmente comercializa principalmente de forma online, cuenta con puntos de venta aliados y realiza envíos a todo el país, buscando ofrecer no solo productos, sino una experiencia para compartir alrededor del fuego."
        ],

        ubicacion: "Asunción, Paraguay",

        whatsapp: "595982754850",

        instagram: "https://www.instagram.com/elfogondelpatio?igsh=MXNydjhlNW5wNWxmeg%3D%3D",

        productoImagen:
            "./assets/img/el-fogon-del-patio/portada-y-foto-1.png",

        perfilImagen:
            "./assets/img/el-fogon-del-patio/foto-de-perfil.jpg",

        fotosCarrusel: [
            "./assets/img/el-fogon-del-patio/portada-y-foto-1.png",
            "./assets/img/el-fogon-del-patio/foto-3.jpeg",
            "./assets/img/el-fogon-del-patio/foto-4.png"
        ],

        promocion:
            "No hay promociones activas actualmente.",

        notaPeriodistica: ""

    },


    {
        nombre: "MAP Crochet",
        categoria: "Moda y diseño",
        verificada: true,

        descripcion:
            "Emprendimiento dedicado a la elaboración artesanal de prendas de crochet.",

        descripcionLarga: [
            "MAP Crochet nació de la pasión de María Ávalos por el crochet, un conocimiento que aprendió de su madre y que comenzó a utilizar para generar ingresos mientras buscaba la forma de cumplir su sueño de estudiar cine. Con el tiempo, pasó de elaborar gorros y bufandas a especializarse en prendas de verano como bikinis, tops, faldas, pareos y vestidos.",
            "En 2015, el emprendimiento le permitió solventar sus gastos mientras estudiaba Cine y Audiovisual en Brasil, carrera de la que se recibió en 2019. Actualmente, MAP Crochet está formalizado, cuenta con tienda online, trabaja con pedidos personalizados y mantiene prendas en stock, mientras busca ampliar su mercado y llegar a clientes del exterior."
        ],

        ubicacion: "Asunción, Paraguay",

        whatsapp: "595971965636",

        instagram: "https://www.instagram.com/map_crochet/?hl=es",

        productoImagen:
            "./assets/img/map-crochet/portada-y-foto-1.jpeg",

        perfilImagen:
            "./assets/img/map-crochet/perfil.jpeg",

        fotosCarrusel: [
            "./assets/img/map-crochet/portada-y-foto-1.jpeg",
            "./assets/img/map-crochet/foto-2.jpg",
            "./assets/img/map-crochet/foto-3.jpeg",
            "./assets/img/map-crochet/foto-4.jpg",
            "./assets/img/map-crochet/foto-5.webp"
        ],

        promocion:
            "Consultá por los servicios disponibles.",

        notaPeriodistica: ""

    },

    {
        nombre: "Creaciones Pascuala",
        categoria: "Moda y diseño",
        verificada: true,

        descripcion:
            "Emprendimiento artesanal dedicado a la confección de bolsos, cartucheras, individuales, fundas y otros artículos de tela.",

        descripcionLarga: [
            "Creaciones Pascuala nació cuando María Pascuala González, a los 76 años, retomó su pasión por la costura después de la pérdida de su esposo. Lo que comenzó como una forma de ocupar su tiempo y sobrellevar el duelo se transformó en un emprendimiento desde su hogar en San Lorenzo, donde confecciona bolsos, cartucheras, individuales, fundas y otros productos de tela.",
            "Con el apoyo de su nieta Sandra, quien creó las redes sociales y comenzó a mostrar sus trabajos en Instagram, Pascuala empezó a recibir pedidos de diferentes puntos del país. Actualmente trabaja de manera artesanal y realiza envíos mediante delivery o encomienda, destacándose especialmente por sus bolsones de tela y cartucheras."
        ],

        ubicacion: "San Lorenzo, Paraguay",

        whatsapp: "595985846621",

        instagram: "https://www.instagram.com/creacionesdepascuala/",

        productoImagen:
            "./assets/img/creaciones-pascuala/foto-producto-principal.jpeg",

        perfilImagen:
            "./assets/img/creaciones-pascuala/foto-perfil.jpeg",

        fotosCarrusel: [
            "./assets/img/creaciones-pascuala/foto-producto-principal.jpeg",
            "./assets/img/creaciones-pascuala/foto-dos.jpeg",
            "./assets/img/creaciones-pascuala/foto-tres.jpeg",
            "./assets/img/creaciones-pascuala/foto-cuatro.jpeg"
        ],

        promocion:
            "Consultá por los servicios disponibles.",

        notaPeriodistica: ""

    },
    
    {
        nombre: "Pedacitos de Luna",
        categoria: "Gastronomía",
        verificada: true,

        descripcion:
            "Emprendimiento gastronómico dedicado a la elaboración y venta de productos dulces y salados en el microcentro de Asunción.",

        descripcionLarga: [
            "Pedacitos de Luna nació en 2023 por Milagros Ríos y Ever Alfonso. Comenzaron con una inversión de apenas G. 150.000, con la que elaboraron 100 medialunas artesanales para una feria por el Día de los Enamorados. En menos de seis horas lograron vender toda la producción, dando inicio a un proyecto que continúa creciendo.",
            "Las medialunas artesanales continúan siendo el producto insignia, pero con el tiempo ampliaron su propuesta con opciones dulces y saladas. Entre sus productos más reconocidos se encuentran los churrasquitos mixtos, preparados con carne y pollo desmechado en pan caliente. También realizan pedidos especiales para eventos."
        ],

        ubicacion: "Asunción, Paraguay",

        // Solo números, sin "+", formato 595 9XX XXXXXX
        whatsapp: "595991305649",

        instagram: "https://www.instagram.com/pedacitos_de_luna__/",

        productoImagen:
            "./assets/img/pedacitos-de-luna/pedacitos-de-luna-foto-de-presentacion.jpeg",

        perfilImagen:
            "./assets/img/pedacitos-de-luna/pedacitos-de-luna-foto-de-perfil.jpeg",

        fotosCarrusel: [
            "./assets/img/pedacitos-de-luna/pedacitos-de-luna-foto-de-presentacion.jpeg",
            "./assets/img/pedacitos-de-luna/pedacitos-de-luna-pancho.jpeg",
            "./assets/img/pedacitos-de-luna/pedacitos-de-luna-empanada.jpeg",
            "./assets/img/pedacitos-de-luna/pedacitos-de-luna-medialuna.jpeg"
        ],

        promocion:
            "No hay promociones activas actualmente.",

        notaPeriodistica: ""

    }
];