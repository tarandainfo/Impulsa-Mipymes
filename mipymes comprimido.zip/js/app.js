// ==========================================
// APP.JS — LÓGICA DE RENDERIZADO
// ==========================================
//
// No hace falta tocar este archivo para agregar
// una mipyme o un banner nuevo: eso se hace en
// mipymes-data.js y banners-data.js.
// ==========================================


// ==========================================
// SLUG (para armar el link a la ficha de
// cada mipyme). Misma lógica que ficha.js.
// ==========================================

function crearSlug(texto) {

    return texto
        .toString()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .trim()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "");

}


// ==========================================
// TONO DE COLOR POR CATEGORÍA
// ==========================================
//
// Cada categoría recibe un número de 0 a 5, estable (según el
// orden en que aparece en MIPYMES_DATA). El CSS lo usa para pintar
// el puntito de color que acompaña a la categoría de cada mipyme.
// Si se agrega una categoría nueva en mipymes-data.js, recibe su
// tono automáticamente.
// ==========================================

const TONOS_CATEGORIA = {};

(function () {

    let n = 0;

    if (typeof MIPYMES_DATA === "undefined") return;

    MIPYMES_DATA.forEach(function (m) {

        const c = String(m.categoria || "").trim();

        if (!(c in TONOS_CATEGORIA)) {
            TONOS_CATEGORIA[c] = n % 6;
            n++;
        }

    });

})();


// ==========================================
// ORDEN DE LAS MIPYMES DESTACADAS: TURNOS PAREJOS
// ==========================================
// La lógica (qué orden toca cada día) está en js/orden.js y se explica
// ahí. Acá solo se calcula el orden de hoy, que usan las tarjetas y la
// portada rotativa.
// ==========================================

// El orden de hoy: lo usan las tarjetas y la portada rotativa
const MIPYMES_ORDENADAS = (typeof MIPYMES_DATA !== "undefined") ? ordenarDestacadas(MIPYMES_DATA) : [];

// Dirección de la ficha de una mipyme. Si el script tools/generar-seo.js ya le armó su
// página (mipymes/<nombre>/, con su vista previa para WhatsApp), se usa esa; si todavía
// no (por ejemplo, una mipyme recién cargada), se usa la ficha de siempre.
function urlDeFicha(mipyme) {

    const slug = crearSlug(mipyme.nombre);
    const generadas = (typeof PAGINAS_GENERADAS !== "undefined" && PAGINAS_GENERADAS.fichas) ? PAGINAS_GENERADAS.fichas : [];

    return generadas.indexOf(slug) >= 0 ? "mipymes/" + slug + "/" : "ficha.html?mipyme=" + slug;

}


function tonoDeCategoria(categoria) {

    const c = String(categoria || "").trim();

    return c in TONOS_CATEGORIA ? TONOS_CATEGORIA[c] : 0;

}


// ==========================================
// CONTENEDORES
// ==========================================

const mipymesList = document.getElementById("mipymes-list");
const mipymesPaginacion = document.getElementById("mipymes-paginacion");
const bannersList = document.getElementById("banners-list");
const btnAparecer = document.getElementById("btn-aparecer");


// ==========================================
// PAGINACIÓN DE MIPYMES
// ==========================================
//
// Se muestran de a MIPYMES_POR_PAGINA mipymes por
// vez. Los anuncios (banners) NO se paginan: se
// muestran siempre completos en su columna.
// ==========================================

const MIPYMES_POR_PAGINA = 3;

let paginaActualMipymes = 1;


// ==========================================
// REVEAL AL HACER SCROLL
// ==========================================
//
// Hace que las tarjetas (y algunos bloques
// fijos) aparezcan con un fade-in + slide-up
// suave cuando entran en pantalla, en vez de
// mostrarse de golpe.
//
// Respeta "prefers-reduced-motion": si el
// usuario tiene esa preferencia activada en
// su sistema, no se anima nada (se muestra
// todo directamente).
// ==========================================

const prefiereMovimientoReducido =
    window.matchMedia &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches;

let observadorReveal = null;

function obtenerObservadorReveal() {

    if (prefiereMovimientoReducido) return null;

    if (!("IntersectionObserver" in window)) return null;

    if (!observadorReveal) {

        observadorReveal = new IntersectionObserver(function (entradas, observer) {

            entradas.forEach(function (entrada) {

                if (!entrada.isIntersecting) return;

                entrada.target.classList.add("reveal-visible");
                observer.unobserve(entrada.target);

            });

        }, {
            threshold: 0.15,
            rootMargin: "0px 0px -40px 0px"
        });

    }

    return observadorReveal;

}


// activarReveal: agrega la animación a un elemento.
// "retrasoMs" es opcional, para escalonar varias
// tarjetas seguidas (que no aparezcan todas juntas).
// "claseBase" es opcional: "reveal" (fade + sube
// desde abajo, por defecto) o "reveal-left" (entra
// deslizándose desde la izquierda, usado en las
// tarjetas de mipymes).
function activarReveal(elemento, retrasoMs, claseBase) {

    if (!elemento) return;

    if (prefiereMovimientoReducido) return;

    if (!("IntersectionObserver" in window)) return;

    elemento.classList.add(claseBase || "reveal");

    if (retrasoMs) {
        elemento.style.transitionDelay = `${retrasoMs}ms`;
    }

    const observador = obtenerObservadorReveal();

    if (observador) observador.observe(elemento);

}


// ==========================================
// MOSTRAR MIPYMES
// ==========================================

function mostrarMipymes() {

    if (!mipymesList) return;

    // Si hay búsqueda o filtros (js/buscador.js), solo se muestran las que coinciden,
    // siempre en el orden de hoy (turnos parejos)
    const listaVisible = window.Buscador
        ? window.Buscador.filtrarDestacadas(MIPYMES_ORDENADAS)
        : MIPYMES_ORDENADAS;

    const totalPaginas =
        Math.ceil(listaVisible.length / MIPYMES_POR_PAGINA) || 1;

    // Por si la página guardada quedó fuera de rango
    // (ej: se borró una mipyme y ya no existe esa página).
    if (paginaActualMipymes > totalPaginas) paginaActualMipymes = totalPaginas;
    if (paginaActualMipymes < 1) paginaActualMipymes = 1;

    const inicio = (paginaActualMipymes - 1) * MIPYMES_POR_PAGINA;

    const mipymesDeEstaPagina = listaVisible.slice(
        inicio,
        inicio + MIPYMES_POR_PAGINA
    );

    mipymesList.innerHTML = "";

    // Ninguna destacada coincide con la búsqueda
    if (!listaVisible.length) {

        const enLaGuia = window.Buscador ? window.Buscador.totales().todas : 0;

        mipymesList.innerHTML = `
            <div class="buscador-vacio">
                <strong>Ninguna mipyme destacada coincide con tu búsqueda.</strong>
                <p>${enLaGuia
                    ? `Pero encontramos ${enLaGuia} ${enLaGuia === 1 ? "mipyme" : "mipymes"} en la <a href="#directorio">guía de mipymes</a>.`
                    : "Probá con otra palabra, o con otro rubro o ciudad."}</p>
                <button type="button" class="buscador-vacio-limpiar">Limpiar la búsqueda</button>
            </div>
        `;

        const botonLimpiar = mipymesList.querySelector(".buscador-vacio-limpiar");

        if (botonLimpiar) botonLimpiar.addEventListener("click", function () { window.Buscador.limpiar(); });

        mostrarPaginacionMipymes(1);

        return;

    }

    mipymesDeEstaPagina.forEach(function (mipyme, indice) {

        const card = document.createElement("article");

        card.classList.add("mipyme-card");

        // tono de color de la categoría (lo usa el CSS para el puntito)
        card.setAttribute("data-tono", tonoDeCategoria(mipyme.categoria));

        // Foto de la tarjeta. Si la mipyme tiene "productoImagenMovil", en celular
        // (pantallas de hasta 600 px, donde la tarjeta pasa a una sola columna y
        // la foto se ve entera) se usa esa foto; si no, siempre la misma.
        const imagenHtml = `<img
                    src="${mipyme.productoImagen}"
                    alt="Producto de ${mipyme.nombre}"
                    loading="lazy"
                    decoding="async"
                >`;

        const imagenDeLaTarjeta = mipyme.productoImagenMovil
            ? `<picture>
                    <source media="(max-width: 600px)" srcset="${mipyme.productoImagenMovil}">
                    ${imagenHtml}
                </picture>`
            : imagenHtml;

        // Palomita de "mipyme verificada" (solo si en los datos dice  verificada: true).
        // Va fuera del link, para que el subrayado al pasar el mouse no la toque.
        const insigniaVerificada = (window.Verificada && window.Verificada.esVerificada(mipyme))
            ? window.Verificada.html(true)
            : "";

        card.innerHTML = `

            <div class="mipyme-product-image">

                ${imagenDeLaTarjeta}

            </div>


            <div class="mipyme-info">

                <div class="mipyme-header">

                    <img
                        class="mipyme-profile-image"
                        src="${mipyme.perfilImagen}"
                        alt="Perfil de ${mipyme.nombre}"
                        loading="lazy"
                        decoding="async"
                    decoding="async"
                    >

                    <div>

                        <span class="mipyme-category">
                            ${mipyme.categoria}
                        </span>

                        <h3>
                            <a class="mipyme-nombre-link" href="${urlDeFicha(mipyme)}">${mipyme.nombre}</a>${insigniaVerificada}
                        </h3>

                    </div>

                </div>


                <p class="mipyme-description">
                    ${mipyme.descripcion}
                </p>


                <p class="mipyme-location">
                    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2C7.86 2 4.5 5.36 4.5 9.5c0 5.25 6.24 11.34 6.5 11.6a1.4 1.4 0 0 0 2 0c.26-.26 6.5-6.35 6.5-11.6C19.5 5.36 16.14 2 12 2zm0 10.3a2.8 2.8 0 1 1 0-5.6 2.8 2.8 0 0 1 0 5.6z"/></svg>
                    ${mipyme.ubicacion}
                </p>


                ${mipyme.promocion ? `
                <div class="mipyme-promotion">

                    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M21.4 11.2 12.8 2.6a2 2 0 0 0-1.4-.6H4a2 2 0 0 0-2 2v7.4c0 .53.21 1.04.6 1.4l8.6 8.6a2 2 0 0 0 2.8 0l7.4-7.4a2 2 0 0 0 0-2.8zM7 8a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z"/></svg>

                    <div>

                        <strong>
                            PROMOCIÓN
                        </strong>

                        <p>
                            ${mipyme.promocion}
                        </p>

                    </div>

                </div>
                ` : ""}


                <div class="mipyme-actions">

                    <a
                        href="https://wa.me/${mipyme.whatsapp}"
                        target="_blank"
                        rel="noopener"
                        class="whatsapp-btn">

                        <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2C6.48 2 2 6.48 2 12c0 1.85.5 3.58 1.35 5.07L2 22l5.06-1.33A9.94 9.94 0 0 0 12 22c5.52 0 10-4.48 10-10S17.52 2 12 2zm5.2 14.2c-.22.62-1.28 1.18-1.77 1.24-.45.06-.98.08-1.58-.1-.36-.11-.83-.27-1.43-.53-2.52-1.09-4.16-3.63-4.29-3.8-.13-.17-1.03-1.37-1.03-2.61 0-1.24.65-1.85.88-2.1.22-.25.49-.31.65-.31.16 0 .33 0 .47.01.15.01.35-.06.55.42.2.49.69 1.68.75 1.8.06.12.1.27.02.44-.08.17-.12.27-.24.42-.12.15-.25.33-.36.44-.12.12-.24.25-.1.49.14.24.61 1.01 1.32 1.63.91.8 1.67 1.05 1.91 1.17.24.12.38.1.52-.06.14-.16.6-.7.76-.94.16-.24.32-.2.53-.12.21.08 1.36.64 1.6.76.24.12.4.18.46.28.06.11.06.61-.16 1.23z"/></svg>
                        WhatsApp

                    </a>


                    <a
                        href="${mipyme.instagram}"
                        target="_blank"
                        rel="noopener"
                        class="instagram-btn">

                        <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="2" y="2" width="20" height="20" rx="6" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="4.3" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="17.3" cy="6.7" r="1.2" fill="currentColor"/></svg>
                        Instagram

                    </a>

                </div>

            </div>

        `;

        mipymesList.appendChild(card);

        // Clickear la tarjeta lleva a la ficha de la mipyme,
        // excepto si el click fue en los botones de contacto.
        card.addEventListener("click", function (e) {

            if (e.target.closest("a, .mipyme-actions")) return;

            window.location.href = urlDeFicha(mipyme);

        });

        activarReveal(card, indice * 90, "reveal-left");

    });

    mostrarPaginacionMipymes(totalPaginas);

    // Publicidad entre las tarjetas (js/ads.js): se vuelve a poner en cada página
    if (window.Publicidad) window.Publicidad.enLista(mipymesList);

}


// ==========================================
// PAGINACIÓN — DIBUJAR CONTROLES
// ==========================================
//
// Estilo "Google": números de página en el centro
// y un botón "Siguiente" al final. Si solo hay una
// página, no se muestra nada.
// ==========================================

function mostrarPaginacionMipymes(totalPaginas) {

    if (!mipymesPaginacion) return;

    mipymesPaginacion.innerHTML = "";

    if (totalPaginas <= 1) return;

    const lista = document.createElement("ul");
    lista.classList.add("paginacion-lista");

    for (let numero = 1; numero <= totalPaginas; numero++) {

        const item = document.createElement("li");

        const boton = document.createElement("button");
        boton.type = "button";
        boton.classList.add("paginacion-num");
        boton.textContent = numero;
        boton.setAttribute("aria-label", `Ir a la página ${numero}`);

        if (numero === paginaActualMipymes) {
            boton.classList.add("activo");
            boton.setAttribute("aria-current", "page");
        }

        boton.addEventListener("click", function () {
            irAPaginaMipymes(numero);
        });

        item.appendChild(boton);
        lista.appendChild(item);

    }

    const itemSiguiente = document.createElement("li");

    const botonSiguiente = document.createElement("button");
    botonSiguiente.type = "button";
    botonSiguiente.classList.add("paginacion-siguiente");
    botonSiguiente.innerHTML = `
        Siguiente
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>
    `;

    const esUltimaPagina = paginaActualMipymes === totalPaginas;
    botonSiguiente.disabled = esUltimaPagina;

    botonSiguiente.addEventListener("click", function () {
        if (!esUltimaPagina) irAPaginaMipymes(paginaActualMipymes + 1);
    });

    itemSiguiente.appendChild(botonSiguiente);
    lista.appendChild(itemSiguiente);

    mipymesPaginacion.appendChild(lista);

}


// ==========================================
// PAGINACIÓN — CAMBIAR DE PÁGINA
// ==========================================

function irAPaginaMipymes(numero) {

    if (numero === paginaActualMipymes) return;

    paginaActualMipymes = numero;

    mostrarMipymes();

    // Sube el scroll al inicio del listado, para que
    // se vea la mipyme #1 de la nueva página.
    document
        .getElementById("mipymes")
        .scrollIntoView({ behavior: "smooth", block: "start" });

}


// ==========================================
// MOSTRAR BANNERS
// ==========================================

function mostrarBanners() {

    if (!bannersList) return;

    bannersList.innerHTML = "";

    BANNERS_DATA.forEach(function (banner, indice) {

        const item = document.createElement("div");

        item.classList.add("banner");

        item.innerHTML = `

            <div class="banner-image ${banner.colorClase || ""}">
                ${banner.imagen
                    ? `<img src="${banner.imagen}" alt="${banner.marca}" loading="lazy">`
                    : banner.marca}
            </div>

            <div class="banner-content">

                <span>
                    ${banner.etiqueta}
                </span>

                <h4>
                    ${banner.titulo}
                </h4>

                <p>
                    ${banner.texto}
                </p>

                <a href="${banner.link}" target="_blank" rel="noopener" class="banner-link">
                    Conocer más →
                </a>

            </div>

        `;

        bannersList.appendChild(item);

        activarReveal(item, indice * 90);

    });

}


// ==========================================
// BOTONES DE CONTACTO (Infonegocios)
// ==========================================

function configurarBotonesContacto() {

    if (typeof INFONEGOCIOS_CONFIG === "undefined") return;

    if (btnAparecer) {

        btnAparecer.href =
            `https://wa.me/${INFONEGOCIOS_CONFIG.whatsapp}?text=${encodeURIComponent(INFONEGOCIOS_CONFIG.mensajeQuieroAparecer)}`;

    }

}


// ==========================================
// SCROLL SUAVE (arriba/abajo según la sección)
// ==========================================
//
// Anima el scroll a mano con requestAnimationFrame,
// en vez de depender del scroll-behavior del navegador.
// Funciona para cualquier link que apunte a un "#id"
// de la misma página (nav, botones, etc).
// ==========================================

function scrollSuaveHacia(destino) {

    const header = document.querySelector(".header");
    const alturaHeader = header ? header.offsetHeight : 0;

    const posicionDestino =
        destino.getBoundingClientRect().top +
        window.pageYOffset -
        alturaHeader -
        20;

    const posicionInicial = window.pageYOffset;
    const distancia = posicionDestino - posicionInicial;
    const duracion = 650;
    let inicioAnimacion = null;

    function easeInOutQuad(t) {
        return t < 0.5
            ? 2 * t * t
            : 1 - Math.pow(-2 * t + 2, 2) / 2;
    }

    function paso(marcaTiempo) {

        if (inicioAnimacion === null) inicioAnimacion = marcaTiempo;

        const transcurrido = marcaTiempo - inicioAnimacion;
        const progreso = Math.min(transcurrido / duracion, 1);

        window.scrollTo(0, posicionInicial + distancia * easeInOutQuad(progreso));

        if (transcurrido < duracion) {
            requestAnimationFrame(paso);
        }

    }

    requestAnimationFrame(paso);

}


function activarScrollSuave() {

    const linksInternos = document.querySelectorAll('a[href^="#"]');

    linksInternos.forEach(function (link) {

        const id = link.getAttribute("href").slice(1);

        if (!id) return;

        link.addEventListener("click", function (e) {

            const destino = document.getElementById(id);

            if (!destino) return;

            e.preventDefault();

            scrollSuaveHacia(destino);

        });

    });

}


// ==========================================
// HERO: logo grande arriba del todo,
// vuelve al diseño normal al scrollear
// ==========================================

function activarHeroLogoGrande() {

    const hero = document.querySelector(".hero");
    const circuloLogo = document.querySelector(".hero-logo-circle");
    const heroContent = document.querySelector(".hero-content");
    const circulosDecoracion = document.querySelectorAll(".hero-decoration .hero-circle");
    const logoHeader = document.querySelector(".header .logo img");

    if (!hero || !circuloLogo || !heroContent) return;

    // Cuántos píxeles de scroll dura toda la animación
    const RANGO_SCROLL = 420;

    // Margen extra (px) entre el borde de la circunferencia y el texto
    const MARGEN = 40;

    // Qué tan "atrás" va la animación respecto al scroll real.
    // Más chico = más lenta y suave. Más grande = más pegada al scroll.
    const SUAVIZADO = 0.09;

    let desplazamientoTexto = 0;
    let progresoObjetivo = 0;
    let progresoActual = 0;
    let loopActivo = false;

    function easeInOutQuad(t) {
        return t < 0.5
            ? 2 * t * t
            : 1 - Math.pow(-2 * t + 2, 2) / 2;
    }

    // Mide, con las posiciones reales de la pantalla, cuánto hay
    // que correr el texto para que no quede pisado por la circunferencia
    function calcularDesplazamiento() {

        if (window.innerWidth <= 900) {
            desplazamientoTexto = 0;
            return;
        }

        // texto en su posición normal, sin ningún desplazamiento aplicado
        heroContent.style.transform = "none";

        const heroRect = hero.getBoundingClientRect();
        const contentRect = heroContent.getBoundingClientRect();

        const bordeCirculo = heroRect.left + heroRect.width * 0.5;
        const distancia = bordeCirculo - contentRect.left + MARGEN;

        desplazamientoTexto = Math.max(distancia, 0);

        heroContent.style.transform = "";

    }

    // Aplica un valor de progreso (0 a 1) ya suavizado a todos los elementos
    function aplicarProgreso(valorSuavizado) {

        const progreso = easeInOutQuad(valorSuavizado);

        // Circunferencia: se achica hacia el borde izquierdo y se desvanece
        circuloLogo.style.opacity = String(1 - progreso);
        circuloLogo.style.transform = `scaleX(${1 - progreso * 0.92})`;

        // Texto: pasa de estar corrido a la derecha, a su lugar normal
        heroContent.style.transform =
            `translateX(${desplazamientoTexto * (1 - progreso)}px)`;

        // Círculos rojo/amarillo normales: aparecen
        circulosDecoracion.forEach(function (c) {
            c.style.opacity = String(progreso);
        });

        // Logo del header: aparece a medida que la circunferencia se va
        if (logoHeader) {
            logoHeader.style.opacity = String(progreso);
        }

    }

    // Loop continuo: en cada cuadro, el progreso "actual" se acerca
    // un poquito más al progreso "objetivo" (el que marca el scroll real).
    // Eso es lo que da la sensación de deslizamiento suave, en vez de
    // saltar exactamente lo que salta el scroll (que con mouse suele
    // avanzar a los tirones).
    function loop() {

        if (window.innerWidth <= 900) {
            heroContent.style.transform = "";
            if (logoHeader) logoHeader.style.opacity = "1";
            loopActivo = false;
            return;
        }

        progresoObjetivo = Math.min(window.scrollY / RANGO_SCROLL, 1);
        progresoActual += (progresoObjetivo - progresoActual) * SUAVIZADO;

        // Si ya casi llegó, lo dejamos exacto y frenamos el loop
        // (para no gastar CPU de más sin necesidad).
        if (Math.abs(progresoObjetivo - progresoActual) < 0.0015) {

            progresoActual = progresoObjetivo;
            aplicarProgreso(progresoActual);
            loopActivo = false;
            return;

        }

        aplicarProgreso(progresoActual);

        requestAnimationFrame(loop);

    }

    function iniciarLoop() {

        if (!loopActivo) {
            loopActivo = true;
            requestAnimationFrame(loop);
        }

    }

    function alRedimensionar() {
        calcularDesplazamiento();
        iniciarLoop();
    }

    calcularDesplazamiento();

    // Arranca ya en la posición correcta según el scroll actual
    // (por si la página carga con la vista ya corrida).
    progresoActual = Math.min(window.scrollY / RANGO_SCROLL, 1);
    progresoObjetivo = progresoActual;
    aplicarProgreso(progresoActual);

    window.addEventListener("scroll", iniciarLoop, { passive: true });
    window.addEventListener("resize", alRedimensionar);

}


// ==========================================
// REVEAL EN BLOQUES FIJOS
// ==========================================
//
// Además de las tarjetas de mipymes/banners
// (que se animan solas al crearse), estos
// bloques del HTML también tienen el efecto
// de aparición al hacer scroll.
// ==========================================

function activarRevealBloquesFijos() {

    document.querySelectorAll("[data-reveal]").forEach(function (elemento) {
        activarReveal(elemento);
    });

}


// ==========================================
// HERO — SPOTLIGHT ROTATIVO
// ==========================================
//
// Muestra, de a una, las mipymes de MIPYMES_DATA
// (js/mipymes-data.js). Es automático: si cargás o
// borrás una mipyme ahí, el spotlight se actualiza
// solo. No muestra ninguna cantidad ni estadística.
//
// Acciones (las mismas que las tarjetas de la lista):
//   - click en la imagen/tarjeta  -> ficha de la mipyme
//   - "Ver ficha"                 -> ficha de la mipyme
//   - WhatsApp / Instagram        -> si la mipyme los tiene
//
// Controles: rota solo cada ~5,5 s, flechas, puntitos,
// teclado (← →) y deslizar con el dedo en el celular.
// Se pausa con el mouse encima, con el foco adentro,
// con la pestaña oculta o si el hero no se ve.
// Si el usuario prefiere menos movimiento, NO rota solo.
// ==========================================

function activarSpotlightHero() {

    const spot = document.getElementById("spotlight");

    if (!spot) return;

    // Sin mipymes cargadas: se oculta el spotlight (el resto sigue andando)
    if (typeof MIPYMES_DATA === "undefined" || !MIPYMES_DATA.length) {
        spot.hidden = true;
        return;
    }

    // En el orden de hoy: arranca con la que quedó primera (turnos parejos)
    const lista = MIPYMES_ORDENADAS;

    const capas = [
        document.getElementById("spotlight-capa-a"),
        document.getElementById("spotlight-capa-b")
    ];

    const elCategoria = document.getElementById("spotlight-categoria");
    const elNombre = document.getElementById("spotlight-nombre");
    const elDesc = document.getElementById("spotlight-desc");
    const elUbicacion = document.getElementById("spotlight-ubicacion");
    const btnFicha = document.getElementById("spotlight-ficha");
    const btnWa = document.getElementById("spotlight-wa");
    const btnIg = document.getElementById("spotlight-ig");
    const progreso = document.getElementById("spotlight-progreso");
    const contPuntos = document.getElementById("spotlight-puntos");
    const btnPrev = document.getElementById("spotlight-prev");
    const btnNext = document.getElementById("spotlight-next");

    const unica = lista.length === 1;
    const autoplayPermitido = !prefiereMovimientoReducido && !unica;

    let indice = 0;
    let capaVisible = 0;
    let cambioId = 0;
    let animando = false;

    // Motivos por los que está en pausa (si hay alguno, no avanza solo)
    const pausas = { mouse: false, foco: false, oculta: false, fuera: false };


    function urlFicha(m) {
        return urlDeFicha(m);
    }


    function precargar(src) {
        return new Promise(function (resolve) {
            const img = new Image();
            img.onload = img.onerror = function () { resolve(); };
            img.src = src;
            // tope de seguridad: si una imagen no responde, no se traba el carrusel
            setTimeout(resolve, 6000);
        });
    }


    function esperar(ms) {
        return new Promise(function (resolve) { setTimeout(resolve, ms); });
    }


    // Puntitos (sin números ni cantidades: solo el nombre para lectores de pantalla)
    if (unica) {
        contPuntos.hidden = true;
        btnPrev.hidden = true;
        btnNext.hidden = true;
    } else {
        lista.forEach(function (m, i) {
            const punto = document.createElement("button");
            punto.type = "button";
            punto.setAttribute("aria-label", `Ver ${m.nombre.trim()}`);
            punto.addEventListener("click", function () {
                irA(i);
            });
            contPuntos.appendChild(punto);
        });
    }


    function pintarTextos(i) {

        const m = lista[i];

        elCategoria.textContent = m.categoria || "";
        elCategoria.hidden = !m.categoria;

        spot.setAttribute("data-tono", tonoDeCategoria(m.categoria));

        elNombre.textContent = m.nombre.trim();

        // Palomita de "mipyme verificada" junto al nombre
        if (window.Verificada && window.Verificada.esVerificada(m)) {
            elNombre.insertAdjacentHTML("beforeend", window.Verificada.html(true));
        }
        elDesc.textContent = m.descripcion || "";
        elUbicacion.textContent = m.ubicacion || "";

        btnFicha.href = urlFicha(m);
        btnFicha.setAttribute("aria-label", `Ver ficha de ${m.nombre.trim()}`);
        btnWa.setAttribute("aria-label", `Escribir por WhatsApp a ${m.nombre.trim()}`);
        btnIg.setAttribute("aria-label", `Ver el Instagram de ${m.nombre.trim()}`);

        if (m.whatsapp) {
            btnWa.href = `https://wa.me/${m.whatsapp}`;
            btnWa.hidden = false;
        } else {
            btnWa.hidden = true;
        }

        if (m.instagram) {
            btnIg.href = m.instagram;
            btnIg.hidden = false;
        } else {
            btnIg.hidden = true;
        }

        Array.from(contPuntos.children).forEach(function (p, n) {
            if (n === i) {
                p.setAttribute("aria-current", "true");
            } else {
                p.removeAttribute("aria-current");
            }
        });

    }


    function mostrarImagen(i) {

        // La imagen nueva va en la capa que está oculta y se hace
        // un fundido entre las dos (así nunca se ve un "salto").
        const siguienteCapa = 1 - capaVisible;
        const m = lista[i];

        capas[siguienteCapa].src = m.productoImagen;
        capas[siguienteCapa].alt = `Producto de ${m.nombre.trim()}`;

        capas[siguienteCapa].classList.add("visible");
        capas[capaVisible].classList.remove("visible");

        capaVisible = siguienteCapa;

    }


    function reiniciarProgreso() {

        progreso.classList.remove("corriendo");
        spot.classList.remove("activo");

        // fuerza al navegador a "olvidar" la animación anterior
        void progreso.offsetWidth;

        if (autoplayPermitido) progreso.classList.add("corriendo");

        spot.classList.add("activo");

    }


    function actualizarPausa() {

        const enPausa = pausas.mouse || pausas.foco || pausas.oculta || pausas.fuera;

        spot.classList.toggle("pausado", enPausa);

    }


    function irA(destino) {

        const nuevo = (destino + lista.length) % lista.length;

        if (nuevo === indice && !animando) {
            reiniciarProgreso();
            return;
        }

        const miCambio = ++cambioId;

        animando = true;

        // 1) Primero se descarga la imagen nueva. Mientras tanto la mipyme
        //    actual sigue a la vista completa (con fotos pesadas o internet
        //    lenta, la tarjeta nunca queda "vacía").
        // 2) Recién cuando la imagen está lista, se hace el fundido y el cambio.
        precargar(lista[nuevo].productoImagen).then(function () {

            if (miCambio !== cambioId) return;

            spot.classList.add("cambiando");

            return esperar(prefiereMovimientoReducido ? 0 : 280);

        }).then(function () {

            if (miCambio !== cambioId) return;

            indice = nuevo;

            mostrarImagen(indice);
            pintarTextos(indice);

            spot.classList.remove("cambiando");
            animando = false;

            reiniciarProgreso();

            // adelanta la descarga de la que viene después
            if (!unica) precargar(lista[(indice + 1) % lista.length].productoImagen);

        });

    }


    // ---------- Estado inicial ----------

    capas[0].src = lista[0].productoImagen;
    capas[0].alt = `Producto de ${lista[0].nombre.trim()}`;
    pintarTextos(0);
    reiniciarProgreso();

    if (!unica) precargar(lista[1].productoImagen);


    // ---------- Avance automático (lo dispara la barra de progreso) ----------

    progreso.addEventListener("animationend", function () {
        irA(indice + 1);
    });


    // ---------- Controles ----------

    btnPrev.addEventListener("click", function () {
        irA(indice - 1);
    });

    btnNext.addEventListener("click", function () {
        irA(indice + 1);
    });

    spot.addEventListener("keydown", function (e) {

        if (unica) return;

        if (e.key === "ArrowLeft") {
            e.preventDefault();
            irA(indice - 1);
        } else if (e.key === "ArrowRight") {
            e.preventDefault();
            irA(indice + 1);
        }

    });


    // Click en la imagen/tarjeta -> ficha (igual que las tarjetas de la lista)
    spot.classList.add("spotlight-stage-click");

    spot.addEventListener("click", function (e) {

        if (e.target.closest("a, button")) return;

        window.location.href = urlFicha(lista[indice]);

    });


    // Deslizar con el dedo (celular)
    let inicioX = null;
    let inicioY = null;

    spot.addEventListener("touchstart", function (e) {
        inicioX = e.touches[0].clientX;
        inicioY = e.touches[0].clientY;
    }, { passive: true });

    spot.addEventListener("touchend", function (e) {

        if (inicioX === null || unica) return;

        const dx = e.changedTouches[0].clientX - inicioX;
        const dy = e.changedTouches[0].clientY - inicioY;

        inicioX = null;

        if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.5) {
            irA(dx < 0 ? indice + 1 : indice - 1);
        }

    }, { passive: true });


    // ---------- Pausas ----------

    spot.addEventListener("mouseenter", function () { pausas.mouse = true; actualizarPausa(); });
    spot.addEventListener("mouseleave", function () { pausas.mouse = false; actualizarPausa(); });

    spot.addEventListener("focusin", function () { pausas.foco = true; actualizarPausa(); });
    spot.addEventListener("focusout", function () { pausas.foco = false; actualizarPausa(); });

    document.addEventListener("visibilitychange", function () {
        pausas.oculta = document.hidden;
        actualizarPausa();
    });

    if ("IntersectionObserver" in window) {

        new IntersectionObserver(function (entradas) {
            pausas.fuera = !entradas[0].isIntersecting;
            actualizarPausa();
        }, { threshold: 0.2 }).observe(spot);

    }

}


// ==========================================
// CÉDULA — TARJETA 3D
// ==========================================
//
// La ilustración de la cédula se inclina siguiendo
// al mouse (con las etiquetas RUC / IRE / DNIT
// flotando por delante). Es solo decoración.
// En celular o con "menos movimiento" queda quieta.
// ==========================================

function activarTarjetaCedula3D() {

    if (prefiereMovimientoReducido) return;
    if (window.matchMedia && window.matchMedia("(pointer: coarse)").matches) return;

    const seccion = document.getElementById("cedula");
    const escena = document.getElementById("cedula-escena");

    if (!seccion || !escena) return;

    seccion.addEventListener("mousemove", function (e) {

        const r = escena.getBoundingClientRect();

        const nx = Math.max(-1, Math.min(1, ((e.clientX - r.left) / r.width - 0.5) * 2));
        const ny = Math.max(-1, Math.min(1, ((e.clientY - r.top) / r.height - 0.5) * 2));

        escena.style.setProperty("--c-ry", (-14 + nx * 16).toFixed(1));
        escena.style.setProperty("--c-rx", (9 - ny * 14).toFixed(1));

    });

    seccion.addEventListener("mouseleave", function () {

        escena.style.removeProperty("--c-ry");
        escena.style.removeProperty("--c-rx");

    });

}


// ==========================================
// FOOTER — VOLVER ARRIBA
// ==========================================

function activarVolverArribaFooter() {

    const boton = document.getElementById("footer-subir");

    if (!boton) return;

    boton.addEventListener("click", function () {

        window.scrollTo({
            top: 0,
            behavior: prefiereMovimientoReducido ? "auto" : "smooth"
        });

    });

}


// ==========================================
// DATOS ESTRUCTURADOS: LISTA DE MIPYMES (SEO)
// ==========================================
//
// Le dice a Google cuáles son las mipymes del sitio y a qué
// ficha lleva cada una. Se arma sola desde js/mipymes-data.js.
// ==========================================

function agregarDatosEstructuradosLista() {

    if (typeof MIPYMES_DATA === "undefined" || !MIPYMES_DATA.length) return;

    const sitio = "https://www.impulsamipymes.com.py";

    const datos = {
        "@context": "https://schema.org",
        "@type": "ItemList",
        "@id": `${sitio}/#lista-mipymes`,
        "name": "Mipymes de Paraguay en Impulsa Mipymes",
        "itemListOrder": "https://schema.org/ItemListUnordered",
        "numberOfItems": MIPYMES_DATA.length,
        "itemListElement": MIPYMES_DATA.map(function (m, i) {
            return {
                "@type": "ListItem",
                "position": i + 1,
                "name": m.nombre.trim(),
                "url": `${sitio}/${urlDeFicha(m)}`
            };
        })
    };

    const script = document.createElement("script");
    script.type = "application/ld+json";
    script.id = "jsonld-lista";
    script.textContent = JSON.stringify(datos);
    document.head.appendChild(script);

}


// ==========================================
// EJECUTAR
// ==========================================

mostrarMipymes();

// Cuando cambia la búsqueda (texto, rubro o ciudad), se vuelve a la primera página
if (window.Buscador) {
    window.Buscador.suscribir(function () {
        paginaActualMipymes = 1;
        mostrarMipymes();
    });
}

mostrarBanners();
configurarBotonesContacto();
activarScrollSuave();
activarHeroLogoGrande();
activarRevealBloquesFijos();
activarSpotlightHero();
activarTarjetaCedula3D();
activarVolverArribaFooter();
agregarDatosEstructuradosLista();
